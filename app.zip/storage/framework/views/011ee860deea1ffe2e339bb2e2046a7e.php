<?php $__env->startSection('content'); ?>
<section class="dashboard">
    <div class="top">
        <i class="uil uil-bars sidebar-toggle"></i>

        <div class="search-box">
            <i class="uil uil-search"></i>
            <form action="<?php echo e(route('jurnal.index')); ?>" method="GET" class="d-flex align-items-center" style="gap:.5rem;">
                <input type="text" name="q" value="<?php echo e($q ?? ''); ?>" placeholder="Cari nama/link rumah jurnal...">
                <button class="btn btn-sm btn-outline-secondary">Cari</button>
            </form>
        </div>

        <img src="/images/profil.png" alt="">
    </div>

    <div class="dash-content">
        <div class="activity">
            <div class="title d-flex align-items-center gap-2">
                <i class="uil uil-clipboard-notes"></i>
                <span class="text">Data Rumah Jurnal</span>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success mt-2"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger mt-2"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger mt-2">
                    <ul class="m-0 ps-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($err); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="row justify-content-end mb-3">
                <div class="col-lg-3 text-end">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah">
                        <i class="uil uil-plus"></i> Tambah Jurnal
                    </button>
                </div>
            </div>

            <table id="datatable" class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th style="width:60px;">No</th>
                        <th>Nama</th>
                        <th>Link</th>
                        <th>Deskripsi</th>
                        <th style="width:110px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $jurnal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(($jurnal->currentPage() - 1) * $jurnal->perPage() + $loop->iteration); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td>
                                <a href="<?php echo e($item->link); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php echo e(\Illuminate\Support\Str::limit($item->link, 45)); ?>

                                </a>
                            </td>
                            <td><?php echo e(\Illuminate\Support\Str::limit($item->deskripsi, 80)); ?></td>
                            <td class="d-flex gap-2">
                                <button class="btn btn-link text-primary p-0 m-0" data-bs-toggle="modal"
                                    data-bs-target="#modalEdit<?php echo e($item->id); ?>" title="Edit">
                                    <i class="uil uil-edit"></i>
                                </button>

                                <form action="<?php echo e(route('jurnal.destroy', $item->id)); ?>" method="POST"
                                      onsubmit="return confirm('Yakin hapus jurnal ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-link text-danger p-0 m-0" title="Hapus">
                                        <i class="uil uil-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center">Belum ada data rumah jurnal.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if(method_exists($jurnal, 'links')): ?>
                <div class="mt-3">
                    <?php echo e($jurnal->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php $__currentLoopData = $jurnal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalEdit<?php echo e($item->id); ?>" tabindex="-1"
    aria-labelledby="modalEditLabel<?php echo e($item->id); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('jurnal.update', $item->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditLabel<?php echo e($item->id); ?>">Edit Rumah Jurnal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo e($item->nama); ?>" required maxlength="150">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Link</label>
                        <input type="url" name="link" class="form-control" value="<?php echo e($item->link); ?>" required maxlength="255" placeholder="https://contoh.com/rumah-jurnal">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="3"><?php echo e($item->deskripsi); ?></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-primary">Update</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="modalTambahLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('jurnal.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTambahLabel">Tambah Rumah Jurnal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama</label>
                        <input type="text" name="nama" class="form-control" required maxlength="150" placeholder="Contoh: Rumah Jurnal ABC">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Link</label>
                        <input type="url" name="link" class="form-control" required maxlength="255" placeholder="https://contoh.com/rumah-jurnal">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" rows="3" placeholder="Opsional"></textarea>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-primary">Simpan</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                </div>
            </div>
        </form>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
    $(function() {
        $('#datatable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\cek-jurnal\resources\views/admin/data-jurnal.blade.php ENDPATH**/ ?>