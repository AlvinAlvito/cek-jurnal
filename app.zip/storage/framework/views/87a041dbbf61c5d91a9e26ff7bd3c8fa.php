

<?php $__env->startSection('content'); ?>
    <section class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>

            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>

            <img src="/images/profil.png" alt="">
        </div>

        <div class="dash-content">
            <div class="activity">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="title">
                        <i class="bi bi-box-seam me-2"></i>
                        <span class="text fs-5">Detail Produk: <strong><?php echo e($produk->nama_produk); ?></strong></span>
                    </div>
                    <a href="<?php echo e(route('hasil.prediksi')); ?>" class="btn btn-primary">
                        Kembali <i class="bi bi-arrow-right"></i>
                    </a>
                </div>

                <table class="table table-hover table-striped border">
                    <thead>
                        <tr>
                            <th>Harga Satuan </th>
                            <th>Persamaan Regresi</th>
                            <th>Intercept (a)</th>
                            <th>Koefisien (b)</th>
                            <th>MAPE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Rp <?php echo e(number_format($produk->harga_satuan)); ?></td>
                            <td><?php echo e($regresi->persamaan); ?></td>
                            <td><?php echo e(round($regresi->a, 2)); ?></td>
                            <td><?php echo e(round($regresi->b, 2)); ?></td>
                            <td><?php echo e($regresi->mape); ?>%</td>

                        </tr>

                    </tbody>
                </table>

                <div class="row">
                    <div class="col-6">
                        
                        <div class="card mb-4">
                            <div class="card-header bg-info text-white">
                                <i class="bi bi-bar-chart-fill me-2"></i> Data Penjualan Aktual (Jan–Jun)
                            </div>
                            <div class="card-body p-0">

                                <table class="table table-hover table-striped border">
                                    <thead>
                                        <tr>
                                            <th>Bulan</th>
                                            <th>Penjualan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $aktual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($bulan); ?></td>
                                                <td><?php echo e($jumlah); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="card mb-4">
    <div class="card-header bg-warning text-dark">
        <i class="bi bi-calculator me-2"></i> Tabel Evaluasi MAPE (Manual)
    </div>
    <div class="card-body p-0">
        <table class="table table-bordered table-striped text-center">
            <thead class="table-light">
                <tr>
                    <th>X</th>
                    <th>Bulan</th>
                    <th>Aktual</th>
                    <th>Prediksi</th>
                    <th>Selisih</th>
                    <th>%Error</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $evaluasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row['x']); ?></td>
                        <td><?php echo e($row['bulan']); ?></td>
                        <td><?php echo e($row['aktual']); ?></td>
                        <td><?php echo e(number_format($row['prediksi'], 2)); ?></td>
                        <td><?php echo e(number_format($row['selisih'], 2)); ?></td>
                        <td><?php echo e(number_format($row['error_percent'], 2)); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr class="fw-bold bg-light">
                    <td colspan="5" class="text-end">MAPE:</td>
                    <td><?php echo e(number_format($mape_manual, 2)); ?>%</td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

                    </div>
                    <div class="col-6">
                        <div class="card mb-4">
                            <div class="card-header bg-success text-white">
                                <i class="bi bi-graph-up-arrow me-2"></i> Prediksi Penjualan (Jul–Des)
                            </div>
                            <div class="card-body p-0">
                                <table class="table table-hover table-striped border">
                                    <thead>
                                        <tr>
                                            <th>Bulan</th>
                                            <th>Prediksi Penjualan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $prediksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($bulan); ?></td>
                                                <td><?php echo e($jumlah); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>


                


                
                <div class="card mb-4">
                    <div class="card-header bg-primary text-light">
                        <i class="bi bi-bar-chart-line-fill me-2"></i> Grafik Penjualan
                    </div>
                    <div class="card-body">
                        <div id="grafikPrediksi" style="height: 350px;"></div>
                    </div>
                </div>


            </div>
        </div>
    </section>


    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script>
        const dataAktual = <?php echo json_encode(array_values($aktual)); ?>; // Jan–Jun
        const dataPrediksi = <?php echo json_encode(array_values($prediksi)); ?>; // Jul–Des
        const namaProduk = <?php echo json_encode($produk->nama_produk); ?>;

        new ApexCharts(document.querySelector("#grafikPrediksi"), {
            chart: {
                type: 'line',
                height: 350
            },
            series: [{
                    name: 'Aktual Jan–Jun',
                    data: dataAktual
                },
                {
                    name: 'Prediksi Jul–Des',
                    data: dataPrediksi
                }
            ],
            xaxis: {
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des']
            },
            stroke: {
                curve: 'smooth'
            },
            title: {
                text: `Perbandingan Data Aktual & Prediksi - ${namaProduk}`,
                align: 'center'
            },
            colors: ['#1E90FF', '#FF5733'],
            markers: {
                size: 4
            }
        }).render();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\prediksi-sembako\resources\views/admin/detail-produk.blade.php ENDPATH**/ ?>